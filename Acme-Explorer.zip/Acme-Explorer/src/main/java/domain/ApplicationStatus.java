
package domain;


public enum ApplicationStatus {
	PENDING, REJECTED, DUE, ACCEPTED, CANCELLED;
}
