
package domain;

public enum PriorityLevel {
	HIGH, NEUTRAL, LOW;
}
